package com.cahyaa.uas_2020_2_pt_lemburanku;

public interface OnCardClickBeranda {
    void onCardClick(int position);
}

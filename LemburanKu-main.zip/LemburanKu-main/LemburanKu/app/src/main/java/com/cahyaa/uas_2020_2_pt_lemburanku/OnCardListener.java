package com.cahyaa.uas_2020_2_pt_lemburanku;

public interface OnCardListener {
    void onCardClick(int position);
}
